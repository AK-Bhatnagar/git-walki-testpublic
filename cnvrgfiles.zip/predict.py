def predict(d):
    return "1"
