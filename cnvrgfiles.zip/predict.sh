#!/bin/bash -l
echo "args"