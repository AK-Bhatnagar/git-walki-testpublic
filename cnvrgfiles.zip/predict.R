predict <- function(a,b){
  print(a)
  print(b)
  as.numeric(a) + as.numeric(b)
}