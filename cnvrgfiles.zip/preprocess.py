def prep(x):
    return 300
